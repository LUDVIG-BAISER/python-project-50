### Hexlet tests and linter status:
[![Actions Status](https://github.com/LUDVIG-BAISER/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LUDVIG-BAISER/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/d4cda0b0f4bffdbfe6be/maintainability)](https://codeclimate.com/github/LUDVIG-BAISER/python-project-50/maintainability)

<a href="https://codeclimate.com/github/LUDVIG-BAISER/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/d4cda0b0f4bffdbfe6be/test_coverage" /></a>